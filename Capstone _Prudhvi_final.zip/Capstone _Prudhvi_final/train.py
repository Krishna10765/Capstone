import sagemaker
from sagemaker.sklearn import SKLearn
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

role = 'arn:aws:iam::381492047582:role/service-role/AmazonSageMaker-ExecutionRole-20240716T085853'
bucket = 'predictive-maintainence-data'
train_prefix = 'sagemakertraining'
script_prefix = 'training_script'
output_prefix = 'output'

# S3 path to the script tar.gz
script_s3_path = f's3://{bucket}/{script_prefix}/script.tar.gz'
output_path = f's3://{bucket}/{output_prefix}/'

logger.info("Creating SKLearn estimator")
try:
    sklearn = SKLearn(
        entry_point='script.py',
        role=role,
        instance_type='ml.m5.xlarge',
        framework_version='0.23-1',
        instance_count=1,
        hyperparameters={
            'n_estimators': 100,
            'random_state': 42
        },
        output_path=output_path,
        code_location=script_s3_path,
        dependencies=['requirements.txt'],
        enable_sagemaker_metrics=True,
        debugger_hook_config=False,
        metric_definitions=[
            {"Name": "validation:accuracy", "Regex": "validation-accuracy=([0-9\\.]+)"},
            {"Name": "train:accuracy", "Regex": "train-accuracy=([0-9\\.]+)"}
        ]
    )
    logger.info("SKLearn estimator created successfully")
except Exception as e:
    logger.error("Error creating SKLearn estimator: %s", e)
    raise

logger.info("Setting up training and test inputs")
try:
    train_input = sagemaker.inputs.TrainingInput(f's3://{bucket}/{train_prefix}/train.csv', content_type='text/csv')
    test_input = sagemaker.inputs.TrainingInput(f's3://{bucket}/{train_prefix}/test.csv', content_type='text/csv')
    logger.info("Training and test inputs set up successfully")
except Exception as e:
    logger.error("Error setting up training and test inputs: %s", e)
    raise

logger.info("Submitting the training job")
try:
    sklearn.fit({'train': train_input, 'test': test_input})
    logger.info("Training job submitted successfully")
except Exception as e:
    logger.error("Error submitting training job: %s", e)
    raise
