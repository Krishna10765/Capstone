import json
import boto3

# Initialize the SageMaker runtime client
runtime = boto3.client('sagemaker-runtime')

def predict(endpoint_name, data):
    response = runtime.invoke_endpoint(
        EndpointName=endpoint_name,
        ContentType='application/json',
        Body=json.dumps(data)
    )
    result = json.loads(response['Body'].read().decode())
    return result

# Replace with your actual endpoint name
endpoint_name = "Custom-sklearn-model-2024-07-17-16-35-04"

# Replace with your actual input data
data = {
    "UDI": 2,
    "Product ID": "M14861",
    "Type": "M",
    "Air temperature [K]": 300.0,
    "Process temperature [K]": 310.0,
    "Rotational speed [rpm]": 1500,
    "Torque [Nm]": 40.0,
    "Tool wear [min]": 10,
    "Target": 0,
    "Failure Type": "No Failure"
}

prediction = predict(endpoint_name, data)
print(prediction)
