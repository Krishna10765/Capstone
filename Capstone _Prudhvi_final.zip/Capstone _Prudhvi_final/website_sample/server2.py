from flask import Flask, request, jsonify, render_template
import requests
import logging
import joblib
import boto3
import os

app = Flask(__name__)

API_GATEWAY_URL = "https://5q1cq0rqld.execute-api.us-east-1.amazonaws.com/addition2"

# Set up logging
logging.basicConfig(level=logging.DEBUG)

@app.route('/')
def index():
    return render_template('index.html')

def load_model():
    s3 = boto3.client('s3')
    bucket_name = 'predictive-maintainence-data'
    model_file = 'BalancedRandomForest.joblib'
    
    # Create a temporary directory to store the model file
    temp_dir = os.path.join(os.getcwd(), 'temp')
    os.makedirs(temp_dir, exist_ok=True)
    
    local_model_path = os.path.join(temp_dir, model_file)

    try:
        s3.download_file(bucket_name, model_file, local_model_path)
        model = joblib.load(local_model_path)
        logging.info("Model loaded successfully")
        return model
    except Exception as e:
        logging.error("Error loading model: " + str(e))
        raise

model = load_model()

@app.route('/predict', methods=['POST'])
def predict_failure():
    data = request.json
    payload = {
        "Type": data['Type'],
        "Rotational speed": data['Rotational speed'],
        "Torque": data['Torque'],
        "Air temperature": data['Air temperature'],
        "Process temperature": data['Process temperature'],
        "Tool wear": data['Tool wear']
    }

    logging.debug(f"Payload received: {payload}")

    try:
        features = [
            float(payload['Type']),
            float(payload['Rotational speed']),
            float(payload['Torque']),
            float(payload['Air temperature']),
            float(payload['Process temperature']),
            float(payload['Tool wear'])
        ]

        logging.debug(f"Features for prediction: {features}")

        prediction = model.predict([features])
        logging.debug(f"Prediction result: {prediction}")

        prediction_text = "Failure" if prediction[0] == 1 else "No Failure"

        return jsonify({'result': prediction_text})
    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
