from flask import Flask, request, jsonify, render_template
import requests
import logging

app = Flask(__name__)

API_GATEWAY_URL = "https://5q1cq0rqld.execute-api.us-east-1.amazonaws.com/addition2"

# Set up logging
logging.basicConfig(level=logging.DEBUG)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict_failure():
    data = request.json
    payload = {
        "Type": data['Type'],
        "Rotational speed": data['Rotational speed'],
        "Torque": data['Torque'],
        "Air temperature": data['Air temperature'],
        "Process temperature": data['Process temperature'],
        "Tool wear": data['Tool wear']
    }

    logging.debug(f"Payload sent to API Gateway: {payload}")

    try:
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.post(API_GATEWAY_URL, headers=headers, json=payload)
        logging.debug(f"Response from API Gateway: {response.status_code} - {response.text}")

        if response.status_code == 200:
            result = response.json()
            return jsonify(result)
        else:
            logging.error(f"Error calling the API: {response.status_code} - {response.text}")
            return jsonify({"error": "Error calling the API"}), response.status_code
    except Exception as e:
        logging.error(f"Exception occurred: {e}")
        return jsonify({"error": "Exception occurred while calling the API"}), 500

if __name__ == '__main__':
    app.run(debug=True)
