from flask import Flask, request, jsonify, send_from_directory
import joblib
import numpy as np
from imblearn.ensemble import BalancedRandomForestClassifier, BalancedBaggingClassifier, RUSBoostClassifier, EasyEnsembleClassifier

app = Flask(__name__)

# Load the saved model (replace 'BalancedRandomForest.joblib' with your actual model filename)
model = joblib.load('BalancedRandomForest.joblib')

@app.route('/')
def index():
    return send_from_directory('', 'index.html')

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        print(f"Received data: {data}")

        # Extract features from the JSON data
        features = [
            data['airTemperature'],
            data['processTemperature'],
            data['rotationalSpeed'],
            data['torque'],
            data['toolWear'],
            data['type'],
            data['additionalFeature']
        ]

        # Convert features to a numpy array and reshape for prediction
        features = np.array(features).reshape(1, -1)
        print(f"Features: {features}")

        # Make prediction
        prediction = model.predict(features)[0]
        print(f"Prediction: {prediction}")

        # Convert prediction to human-readable form
        prediction_text = "Failure" if prediction == 1 else "No Failure"
        print(f"Prediction text: {prediction_text}")

        return jsonify({'prediction': prediction_text})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
